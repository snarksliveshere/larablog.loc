<h1>Спасибо, кликните по ссылке</h1>
<a href="http://larablog.loc/verify/{{ $subscriber->token }}">{{$subscriber->token}}</a>
